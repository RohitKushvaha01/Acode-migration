acode.setPluginInit("app.acode.ios-install-fixture", async (baseUrl, page, options) => {
    const data = await fetch(baseUrl + "/assets/payload%20%23%20%E6%97%A5%E6%9C%AC%E8%AA%9E.bin").then(r => r.arrayBuffer());
    const checksum = await new Promise((resolve, reject) => cordova.exec(resolve, reject, "System", "checksumText", ["Acode fixture"]));
    const secret = await options.ctx.getSecret("fixture-missing", "default");
    window.iosInstalledPlugin = { bytes: [...new Uint8Array(data)], checksum, firstInit: options.firstInit, secret };
});
acode.setPluginUnmount("app.acode.ios-install-fixture", () => { delete window.iosInstalledPlugin; });
